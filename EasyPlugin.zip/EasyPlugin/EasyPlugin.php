<?php
/**
User: Nichlas Nielsen
Date: 17-03-2018
Time: 19:18
Plugin Name:  EasyPlugin
Plugin URI:   https://github.com/Masternn54
Description:  Basic plugin
Version:      1
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
 */


